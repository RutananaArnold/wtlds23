

<?php $__env->startSection('content'); ?>

<?php if(Session::has('devices.addDevice')): ?>
   <span><?php echo e(Session::get('devices.addDevice')); ?></span>
<?php endif; ?>

<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Device</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo e(route('addDevice')); ?>" method="post">
               <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="name">Device Name</label>
                    <input type="text" class="form-control" id="name" placeholder="Enter Device name" name="name">
                  </div>

                  <div class="form-group">
                    <label for="latitude">Latitude</label>
                    <input type="text" class="form-control" id="latitude" placeholder="Latitude" name="latitude">
                  </div>

                  <div class="form-group">
                    <label for="longitude">Longitude</label>
                    <input type="text" class="form-control" id="longitude" placeholder="longitude" name="longitude">
                  </div>

                  <div class="form-group">
                    <label for="deploymentLocation">Deployment Location</label>
                    <input type="text" class="form-control" id="deploymentLocation" placeholder="deploymentLocation" name="deploymentLocation">
                  </div>

                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\php8\htdocs\wtlds23\resources\views/devices/addDevice.blade.php ENDPATH**/ ?>
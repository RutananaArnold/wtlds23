

<?php $__env->startSection('content'); ?>
                    <div class="alert alert-info">
                        Devices
                    </div>
             <div class="card">
             <div class="text-right"><a href="/deviceStatus"><button type="button" class="btn btn-success">Device Status</button></a></div>

              <div class="card-header">
                <h3 class="card-title">Installed Devices</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                  <thead>
                    <tr>
                      <th>Device Name</th>
                      <th>Latitude</th>
                      <th>Longitude</th>
                      <th>Deployment Location</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($device->name); ?></td>
                        <td><?php echo e($device->latitude); ?></td>
                        <td><?php echo e($device->longitude); ?></td>
                        <td><?php echo e($device->deploymentLocation); ?></td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

           <div class="text-right"><a href="/addDevice"><button type="button" class="btn btn-info">Add Device</button></a></div>

                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\php8\htdocs\wtlds23\resources\views/devices/devices.blade.php ENDPATH**/ ?>